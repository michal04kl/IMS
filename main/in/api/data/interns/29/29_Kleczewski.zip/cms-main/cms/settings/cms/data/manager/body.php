<link rel='stylesheet' href='/settings/frameworki/bootstrap.css'>
<link rel='stylesheet' href='bd.css'>
<div class='row'>
    <?php include $_SERVER['DOCUMENT_ROOT']."/settings/cms/edit/show.php"; ?>
</div>