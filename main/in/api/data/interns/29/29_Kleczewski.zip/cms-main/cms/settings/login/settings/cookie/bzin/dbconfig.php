<?PHP
$server="localhost";
$user="cms";
$pass="0M5IzcjB-BRiXqiC";
$base="cms";
?>